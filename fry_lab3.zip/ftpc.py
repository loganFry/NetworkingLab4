import socket
from socket import IPPROTO_TCP
import sys
import ipaddress
import os
import time
import socket_helpers


def get_inputs():
    """
    Gets user inputs of server IP address, server port number, local troll port number, and file path, and checks to 
    ensure they are valid.
    """
    
    # Test that all inputs are present
    if len(sys.argv) <= 4:
        print('Must specify server IP address, server port number, troll port number, and file path')
        sys.exit()

    # Check local IP address
    server_ip = sys.argv[1]
    try:
        # Looks up a hostname to IP address if necessary, if not just returns
        # the same IP address
        server_ip = socket.gethostbyname(server_ip)
    except:
        print('IP address is not valid')
        sys.exit()

    # Ensure server port number is valid
    try:
        server_port = int(sys.argv[2])
    except ValueError:
        print('Server port is not an integer')
        sys.exit()

    # Ensure troll port number is valid
    try:
        troll_port = int(sys.argv[3])
    except ValueError:
        print('Troll port is not an integer')
        sys.exit()

    # Ensure input file exists
    file_path = sys.argv[4]
    if not os.path.isfile(file_path):
        print('Input file is not a valid file path')
        sys.exit()

    return (server_ip, server_port, troll_port, file_path)



def send_metadata(file_path, sock, troll_port, client_ip, client_port):
    """
    Sends metadata about a given file over a TCP connection.
    
    Args:
        file_path: The file to send information about
        connection: The TCP connection to send the data over
        troll_port: The local port number on which troll is running
        client_ip: IP address of the client machine
        client_port: The local port number on which the client is running
    """
    seg_1_acked = False
    seg_2_acked = False

    while not seg_1_acked or not seg_2_acked:
        # Check if the server told us to what to send next
        try:
            data = sock.recv(1000 + socket_helpers.HEADER_SIZE)
            ip, port, flag, seq = socket_helpers.read_header(data)

            if flag == 2:
                # if server sends 2, it means it received seg 1
                seg_1_acked = True
                print('seg 1 ACKed')
            elif flag == 3:
                # if server sends 3, it means it received seg 2
                seg_2_acked = True
                print('seg 2 ACKed')
        except:
            pass

        if not seg_1_acked:
            # Send the first segment with header and 4 byte file size
            header = socket_helpers.create_header(client_ip, client_port, 1)
            # Get the size of the file in bytes
            file_size = os.path.getsize(file_path).to_bytes(4, byteorder='big')
            segment_1 = header + file_size
            sock.sendto(segment_1, ('', troll_port))

        # Sleep to avoid overrunning UDP buffers
        time.sleep(0.01)

        if seg_1_acked and not seg_2_acked:
            # Send the second segment with header and 20 byte file name
            header = socket_helpers.create_header(client_ip, client_port, 2)
            # Get the file name (without path)
            file_name = socket_helpers.fill_fixed_bytes(os.path.basename(file_path), 20) 
            segment_2 = header + file_name
            sock.sendto(segment_2, ('', troll_port))

def send_file(file_path, sock, troll_port, client_ip, client_port):
    """
    Sends the data inside a given file using a UDP socket.
    
    Args:
        file_path: The file to send
        sock: The UDP socket to send data over.
        troll_port: The local port number on which troll is running
        client_ip: The IP of the client machine
        client_port: The local port number on which the client is running
    Raises:
        Exception: raised if there are any errors during file transfer
    """
    
    try:
        # Open the file in binary read mode
        f = open(file_path, 'rb')

        # Initialize sequence number
        current_seq = 0
   
        while True:

            # Check if the server has requested a retransmission of data
            try:
                data = sock.recv(1000 + socket_helpers.HEADER_SIZE)
                ip, port, flag, seq = socket_helpers.read_header(data)
                # If the server requested a different sequence number, move to that point
                # in the file
                if seq != current_seq:
                    print('retransmit request received, moving seq to ' + str(seq))
                    current_seq = seq
                    f.seek(1000 * seq)
            except Exception as e:
                # An exception is thrown if no data was received, if so just proceed
                # with file transfer
                pass

            # Get data to send
            header = socket_helpers.create_header(client_ip, client_port, 3, current_seq)
            chunk = f.read(1000)

            # If the chunk is an empty byte, we've reached the end of the file
            if chunk == b'':
                break

            while True:
                try:
                    # Send the chunk
                    sock.sendto(header + chunk, ('', troll_port))
                    break
                except Exception as e:
                    print('unable to send chunk ' + str(current_seq) + ': ' + str(e))

            # Sleep to avoid overrunning UDP buffers, move to next chunk of file
            time.sleep(0.01)
            current_seq += 1

    except Exception as e:
        raise
    finally:
        f.close()

# Begin main code
if __name__ == '__main__':

    # User inputs
    LOCAL_IP, SERVER_PORT, TROLL_PORT, FILENAME = get_inputs()
    # Constant client ip and port
    CLIENT_PORT = 5555

    # Create the UDP socket and bind to client port (required for troll)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', CLIENT_PORT))
    # turn off blocking so we can intermittently listen for messages from server
    sock.setblocking(False)
    print('client socket binded to ip ' + socket.gethostbyname(socket.gethostname()) + ', port ' + str(CLIENT_PORT))
    print('sending all packets to troll port ' + str(TROLL_PORT))

    try:
        # Send meta data
        send_metadata(FILENAME, sock, TROLL_PORT, LOCAL_IP, CLIENT_PORT)

        # Send file
        send_file(FILENAME, sock, TROLL_PORT, LOCAL_IP, CLIENT_PORT)
    except Exception as e:
        print('Error while sending file: ' + str(e))
    else:
        print('File transferred successfully')
    finally:
        # Close the connection
        sock.close()  

    

    
