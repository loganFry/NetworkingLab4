import socket
import sys
import os
import socket_helpers
import time
from enum import Enum


# Enum to represent states of the server
class ServerState(Enum):
    AwaitingFileSize = 1
    AwaitingFileName = 2
    AwaitingFile = 3

# globals state variables
CLIENT_IP = ''
CLIENT_PORT = 0
IP = ''
PORT = 0
state = ServerState.AwaitingFileSize

def get_port():
    """
    Gets the port number entered by the user and ensures it is valid.
    """
    
    # Ensure a port argument was provided
    if len(sys.argv) <= 1:
        print('No port specified, please provide a local port number')
        sys.exit()
    else:
        # Ensure the port number is a valid integer
        try:
            port = int(sys.argv[1])
        except ValueError:
            print('Port must be a valid integer')
            sys.exit()
        return port

def receive_file(sock, file_size, file_name):
    """
    Receives file data over a TCP connection.
    
    Args:
        sock: The UDP socket to receive data over.
        file_size: Size of the file in bytes.
        file_name: Name of the file.
    """
    
    # Ensure that the output directory exists
    output_dir = 'recv'
    create_output_dir(output_dir)

    current_seq = 0
    total_read = 0.0

    # Open the new file in binary write mode
    with open(os.path.join(output_dir, file_name), 'wb') as f:
        # Read chunks of the file until we reach the file size
        while total_read < file_size:
            data = s.recv(1000 + socket_helpers.HEADER_SIZE)
            ip, port, flag, seq = socket_helpers.read_header(data)
            if not ensure_correct_client(ip, port):
                continue

            if seq != current_seq:
                print('seq mismatch, expected ' + str(current_seq) + ', got ' + str(seq))
                request_retransmit(sock, current_seq)
            else:
                # Write the chunk to the new file and increment counter
                f.write(data[socket_helpers.HEADER_SIZE:])
                total_read += 1000.0
                current_seq += 1
                if seq % 100 == 0:
                    print('wrote all seq through ' + str(seq) + ' to file')

def request_retransmit(sock, seq):
    """
    Sends a message back to the client, telling it to go back to sequence number
    seq and resume file transfer there. Used to recover from dropped or out of order
    datagrams.
    
    Args:
        sock: The UDP socket
        seq: Sequence number to go back to
    """

    # Make the header with the new sequence number and sent to client
    global CLIENT_IP
    global CLIENT_PORT
    header = socket_helpers.create_header(IP, PORT, 3, seq)
    sock.sendto(header, (CLIENT_IP, CLIENT_PORT))

def create_output_dir(output_dir):
    """
    Creates the output directory if it does not yet exist.
    
    Args:
        output_dir: Name of the output directory
    """

    if not os.path.isdir(output_dir):
        os.mkdir(output_dir)

def ensure_correct_client(ip, port):
    # Set client ip and port if not set yet
    global CLIENT_IP
    global CLIENT_PORT
    if CLIENT_IP == '' or CLIENT_PORT == 0:
        CLIENT_IP = ip
        CLIENT_PORT = port

    # Only accept data from the client we're currently communicating with
    if CLIENT_IP != ip or CLIENT_PORT != port:
        return False
    else:
        return True


# Begin main code
if __name__ == '__main__':
    HOST = '' # Symbolic name meaning all available interfaces
    # Get port number to open socket on
    PORT = get_port()
    IP = socket.gethostbyname(socket.gethostname())

    # Create the socket and bind to port
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((HOST, PORT))
    print('server socket binded to ip ' + IP + ', port ' + str(PORT))

    # Initialize server state
    file_size = 0
    file_name = ''
    current_seq = 0
    total_read = 0.0
    file_open = False

    # Main state loop
    while True:
        try:
            if state == ServerState.AwaitingFileSize:
                # Get data and read header
                data = s.recv(1000 + socket_helpers.HEADER_SIZE)
                ip, port, flag, seq = socket_helpers.read_header(data)
                if not ensure_correct_client(ip, port):
                    continue

                if flag == 1:
                    # Client sent file size
                    size_data = data[socket_helpers.HEADER_SIZE:socket_helpers.HEADER_SIZE + 4]
                    file_size = int.from_bytes(size_data, byteorder='big')
                    print('segment 1 received, file size is ' + str(file_size) + ' bytes')
                    state = ServerState.AwaitingFileName
                    header = socket_helpers.create_header(IP, PORT, 2)
                    s.sendto(header, (CLIENT_IP, CLIENT_PORT))
                    print('sent seg 1 ACK')
            elif state == ServerState.AwaitingFileName:
                # Get data and read header
                data = s.recv(1000 + socket_helpers.HEADER_SIZE)
                ip, port, flag, seq = socket_helpers.read_header(data)
                if not ensure_correct_client(ip, port):
                    continue

                if flag == 2:
                    # Client sent file name
                    name_data = data[socket_helpers.HEADER_SIZE:socket_helpers.HEADER_SIZE + 20]
                    file_name = name_data.decode('utf-8', 'ignore').strip()
                    print('segment 2 received, file name is ' + file_name)
                    state = ServerState.AwaitingFile
                    header = socket_helpers.create_header(IP, PORT, 3)
                    s.sendto(header, (CLIENT_IP, CLIENT_PORT))
                    print('sent seg 2 ACK')
            elif state == ServerState.AwaitingFile:
                receive_file(s, file_size, file_name)
                print('File transferred successfully')
                break
        except Exception as e:
            print('Error while receiving data: ' + str(e))